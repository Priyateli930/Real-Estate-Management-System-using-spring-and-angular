import { Component, OnInit } from '@angular/core';
import { PropertyTransactionsService } from '../../services/property-transactions.service';

@Component({
  selector: 'app-transaction-history',
  templateUrl: './transaction-history.component.html',
  styleUrl: './transaction-history.component.css'
})
export class TransactionHistoryComponent  implements OnInit {
  transactions: any[] = [];
  selectedTransaction: any = {};
  empty:boolean=false;


  pageNo: number = 0; // Declare pageNo here
  totalPages: number = 0; // Declare totalPages here


  constructor(private transactionService: PropertyTransactionsService) { }

  ngOnInit(): void {
    const userId = localStorage.getItem('userId');
    console.log(userId);
    if(userId)
    {
      this.transactionService.getTransactions(userId).subscribe(data => {
        console.log(data);
        this.totalPages = data.totalPages;
        this.transactions = data.content.filter((transaction: any) => transaction.sellerid === +userId);
        this.empty = this.transactions.length === 0;
      });
    }

  }


  editTransaction(transaction: any): void {
    this.selectedTransaction = { ...transaction };
  }

  updateTransaction(): void {
    this.transactionService.updateTransaction(this.selectedTransaction.transactionid, this.selectedTransaction).subscribe(
      (      response: any) => console.log('Transaction updated!', response),
      (      error: any) => console.error('Error occurred while updating transaction', error)
    );
  }



  deleteTransaction(id: number): void {
    this.transactionService.deleteTransaction(id).subscribe(
      response => {
        console.log('Transaction deleted!', response);
        this.transactions = this.transactions.filter(transaction => transaction.transactionid !== id);
      },
      error => console.error('Error occurred while deleting transaction', error)
    );
  }



  prevPage(): void {
    if (this.pageNo > 0) {
      this.pageNo--;
      this.ngOnInit();
    }
  }

  nextPage(): void {
    if (this.pageNo < this.totalPages - 1) {
      this.pageNo++;
      this.ngOnInit();
    }
  }

  goToPage(page: number): void {
    this.pageNo = page;
    this.ngOnInit();
  }



}
