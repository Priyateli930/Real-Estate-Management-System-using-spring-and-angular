import { Component } from '@angular/core';

@Component({
  selector: 'app-prop-images',
  templateUrl: './prop-images.component.html',
  styleUrl: './prop-images.component.css'
})
export class PropImagesComponent {

}
