import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PropImagesComponent } from './prop-images.component';

describe('PropImagesComponent', () => {
  let component: PropImagesComponent;
  let fixture: ComponentFixture<PropImagesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PropImagesComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PropImagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
