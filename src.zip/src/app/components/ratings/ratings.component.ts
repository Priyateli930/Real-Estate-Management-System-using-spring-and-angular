import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RatingsService } from '../../services/ratings.service';


@Component({
  selector: 'app-ratings',
  templateUrl: './ratings.component.html',
  styleUrl: './ratings.component.css'
})
export class RatingsComponent implements OnInit {

  ratingsForm: FormGroup = this.fb.group({});

  constructor(private fb: FormBuilder, private ratingsService: RatingsService) { }

  ngOnInit() {
    this.ratingsForm = this.fb.group({
      property: ['', Validators.required],
      user: ['', Validators.required],
      ratingvalue: ['', [Validators.required, Validators.min(1), Validators.max(5)]],
      feedback: ['', Validators.required],
      dateoffeedback: ['', Validators.required]
    });
  }

  // onSubmit() {
  //   if (this.ratingsForm.valid) {
  //     this.ratingsService.addRatings(this.ratingsForm.value).subscribe(
  //       (response) => console.log('Ratings added!', response),
  //       (error) => console.log('Error occurred while adding ratings', error)
  //     );
  //   }
  // }

}
