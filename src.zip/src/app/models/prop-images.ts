export interface PropImages {
    propImages: string;
    propertyid: number;
    imageid: number;
  }
