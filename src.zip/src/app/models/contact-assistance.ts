export interface ContactAssistance {
    id: number;
    user: any; // Replace 'any' with the type of 'user'
    cname: string;
    cemail: string;
    phone: string;
    subject: string;
    message: string;
  }
  