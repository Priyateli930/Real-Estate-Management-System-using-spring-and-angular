export interface Users {
  userid?: any;
  username?: any;
  usertype?: any;
  contactno?: any;
  email?: any;
  addressline1?: any;
  addressline2?: any;
  city?: any;
  state?: any;
  pincode?: any;
  dateofbirth?: any;
  verified?: any;
  passwordhash?: any;
}
