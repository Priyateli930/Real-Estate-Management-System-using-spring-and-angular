export interface PropertyTransactions {
    transactionid: number;
    property: any; // Replace 'any' with the type of 'property'
    buyertenant: any; // Replace 'any' with the type of 'buyertenant'
    salerentprice: number;
    transactiondate: string;
    sellerid: number;
  }
  