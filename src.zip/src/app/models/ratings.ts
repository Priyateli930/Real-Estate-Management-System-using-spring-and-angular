export interface Ratings {
    // ratingid: number;
    property: any; // Replace 'any' with the type of 'property'
    user: any; // Replace 'any' with the type of 'user'
    ratingvalue: number;
    feedback: string;
    dateoffeedback: string;
  }
