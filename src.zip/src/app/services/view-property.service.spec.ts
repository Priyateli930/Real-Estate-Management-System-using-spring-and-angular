import { TestBed } from '@angular/core/testing';

import { ViewPropertyService } from './view-property.service';

describe('ViewPropertyService', () => {
  let service: ViewPropertyService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ViewPropertyService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
