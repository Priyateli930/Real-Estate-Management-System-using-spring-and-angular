import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Users } from '../models/users';

@Injectable({
  providedIn: 'root'
})
export class PropertiesService {

  private apiUrl = 'http://localhost:8081/api/v1/rems/services';

  constructor(private http: HttpClient) { }


  getUserById(userId: string): Observable<Users> {
    const jwtToken = localStorage.getItem('jwtToken'); // Get the JWT from local storage
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${jwtToken}`
      })
    };

    return this.http.get<Users>(`${this.apiUrl}/forall/usersbyid/${userId}`, httpOptions);
  }

  addPropertyOwner(property: any): Observable<any> {
    console.log(property);
    const jwtToken = localStorage.getItem('jwtToken'); // Get the JWT from local storage
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${jwtToken}`
      })
    };

    return this.http.post(`${this.apiUrl}/owner/addproperties`, property, httpOptions);
  }




  addPropertyBroker(property: any): Observable<any> {
    console.log(property);
    const jwtToken = localStorage.getItem('jwtToken'); // Get the JWT from local storage
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${jwtToken}`
      })
    };

    return this.http.post(`${this.apiUrl}/broker/addproperties`, property, httpOptions);
  }


}
