import { TestBed } from '@angular/core/testing';

import { ContactAssistanceService } from './contact-assistance.service';

describe('ContactAssistanceService', () => {
  let service: ContactAssistanceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ContactAssistanceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
