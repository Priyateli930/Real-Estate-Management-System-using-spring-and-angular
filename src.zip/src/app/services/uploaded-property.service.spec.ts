import { TestBed } from '@angular/core/testing';

import { UploadedPropertyService } from './uploaded-property.service';

describe('UploadedPropertyService', () => {
  let service: UploadedPropertyService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UploadedPropertyService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
