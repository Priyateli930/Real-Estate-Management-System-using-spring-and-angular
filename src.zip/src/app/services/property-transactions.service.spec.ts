import { TestBed } from '@angular/core/testing';

import { PropertyTransactionsService } from './property-transactions.service';

describe('PropertyTransactionsService', () => {
  let service: PropertyTransactionsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PropertyTransactionsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
