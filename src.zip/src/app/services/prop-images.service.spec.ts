import { TestBed } from '@angular/core/testing';

import { PropImagesService } from './prop-images.service';

describe('PropImagesService', () => {
  let service: PropImagesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PropImagesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
